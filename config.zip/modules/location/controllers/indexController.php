
<?php
function construct()
{
    load_model("location");
};
function getLocationListAction(){
    echo json_encode(getListLocation());
}
function getLocationAction(){
    $id=$_GET['id'];
    echo json_encode(getLocationById($id));
}
function setLocationAction(){
    $data=json_decode('{"data":[{"id":294,"name":"H\u1ed3 Ch\u00ed Minh"},{"id":297,"name":"H\u00e0 N\u1ed9i"},{"id":291,"name":"\u0110\u00e0 N\u1eb5ng"},{"id":278,"name":"An Giang"},{"id":280,"name":"B\u00e0 R\u1ecba - V\u0169ng T\u00e0u"},{"id":282,"name":"B\u1eafc Giang"},{"id":281,"name":"B\u1eafc K\u1ea1n"},{"id":279,"name":"B\u1ea1c Li\u00eau"},{"id":283,"name":"B\u1eafc Ninh"},{"id":284,"name":"B\u1ebfn Tre"},{"id":285,"name":"B\u00ecnh D\u01b0\u01a1ng"},{"id":286,"name":"B\u00ecnh Ph\u01b0\u1edbc"},{"id":287,"name":"B\u00ecnh Thu\u1eadn"},{"id":316,"name":"B\u00ecnh \u0110\u1ecbnh"},{"id":289,"name":"C\u00e0 Mau"},{"id":290,"name":"C\u1ea7n Th\u01a1"},{"id":288,"name":"Cao B\u1eb1ng"},{"id":293,"name":"Gia Lai"},{"id":295,"name":"H\u00e0 Giang"},{"id":296,"name":"H\u00e0 Nam"},{"id":299,"name":"H\u00e0 T\u0129nh"},{"id":300,"name":"H\u1ea3i D\u01b0\u01a1ng"},{"id":301,"name":"H\u1ea3i Ph\u00f2ng"},{"id":319,"name":"H\u1eadu Giang"},{"id":302,"name":"Ho\u00e0 B\u00ecnh"},{"id":320,"name":"H\u01b0ng Y\u00ean"},{"id":321,"name":"Kh\u00e1nh H\u00f2a"},{"id":322,"name":"Ki\u00ean Giang"},{"id":323,"name":"Kon Tum"},{"id":304,"name":"Lai Ch\u00e2u"},{"id":306,"name":"L\u00e2m \u0110\u1ed3ng"},{"id":305,"name":"L\u1ea1ng S\u01a1n"},{"id":324,"name":"L\u00e0o Cai"},{"id":325,"name":"Long An"},{"id":326,"name":"Nam \u0110\u1ecbnh"},{"id":327,"name":"Ngh\u1ec7 An"},{"id":307,"name":"Ninh B\u00ecnh"},{"id":328,"name":"Ninh Thu\u1eadn"},{"id":329,"name":"Ph\u00fa Th\u1ecd"},{"id":308,"name":"Ph\u00fa Y\u00ean"},{"id":309,"name":"Qu\u1ea3ng B\u00ecnh"},{"id":310,"name":"Qu\u1ea3ng Nam"},{"id":311,"name":"Qu\u1ea3ng Ng\u00e3i"},{"id":330,"name":"Qu\u1ea3ng Ninh"},{"id":312,"name":"Qu\u1ea3ng Tr\u1ecb"},{"id":313,"name":"S\u00f3c Tr\u0103ng"},{"id":331,"name":"S\u01a1n La"},{"id":332,"name":"T\u00e2y Ninh"},{"id":333,"name":"Th\u00e1i B\u00ecnh"},{"id":334,"name":"Th\u00e1i Nguy\u00ean"},{"id":335,"name":"Thanh H\u00f3a"},{"id":303,"name":"Th\u1eeba Thi\u00ean Hu\u1ebf"},{"id":336,"name":"Ti\u1ec1n Giang"},{"id":314,"name":"Tr\u00e0 Vinh"},{"id":315,"name":"Tuy\u00ean Quang"},{"id":337,"name":"V\u0129nh Long"},{"id":338,"name":"V\u0129nh Ph\u00fac"},{"id":339,"name":"Y\u00ean B\u00e1i"},{"id":292,"name":"\u0110\u1eafk L\u1eafk"},{"id":340,"name":"\u0110\u1eafk N\u00f4ng"},{"id":341,"name":"\u0110i\u1ec7n Bi\u00ean"},{"id":317,"name":"\u0110\u1ed3ng Nai"},{"id":318,"name":"\u0110\u1ed3ng Th\u00e1p"}]}');
    $data=$data['data'];
    foreach ($data as $info){
        insertLocation($info['id'],$info['name']);
    }
    echo "OK";
}
